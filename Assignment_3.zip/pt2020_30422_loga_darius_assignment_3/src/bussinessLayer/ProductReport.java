package bussinessLayer;

import java.util.NoSuchElementException;
import dao.ProductDAO;
import model.Product;

/**Bussiness Logic class for Product
 * @author Loga Darius
 *
 */
public class ProductReport 
{
	private ProductDAO dao;
	/**
	 * Constructor
	 */
	public ProductReport() 
	{
		dao = new ProductDAO();
	}
	/**
	 * Finds a product by its id, if not found throws an exception
	 * @param id identifier of product
	 * @return the found product
	 */
	public Product findProductById(int id) 
	{
		Product c = dao.findById(id);
		if (c == null) 
		{
			throw new NoSuchElementException("The product with id =" + id + " was not found!");
		}
		return c;
	}
	/**
	 * Inserts a product in the Product table, if its attributes are valid
	 * @param c product to be inserted
	 * @return the id of the inserted product
	 */
	public Product insertProduct(Product c) 
	{
		return dao.insert(c);
	}
	/**
	 * Updates a product
	 * @param c the product to be updated
	 * @return the result after the update
	 */
	public Product updateProduct(Product c)
	{
		Product toUpdate = this.findProductById(c.getId());
		if(toUpdate != null)
		{
			return dao.update(c);
		}
		else throw new NoSuchElementException("The Product with id = " + c.getId() + " was not found!");
	}
	/**
	 * Deletes a product
	 * @param c the product to be deleted
	 * @return the result after the delete
	 */
	public Product deleteProduct(Product c)
	{
			return dao.delete(c);
	}
}