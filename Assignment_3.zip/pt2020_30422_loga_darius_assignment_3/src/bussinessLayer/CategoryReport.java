package bussinessLayer;

import java.util.NoSuchElementException;
import dao.CategoryDAO;
import model.Category;

/**Bussiness Logic class for Category
 * @author Loga Darius
 *
 */
public class CategoryReport 
{
	
	private CategoryDAO dao;
	
	public CategoryReport() 
	{
		dao = new CategoryDAO();
	}
	/**
	 * Finds a category by id throw an exception if not found
	 * @param id identifier for a category
	 * @return
	 */
	public Category findCategoryById(int id) 
	{
		Category c = dao.findById(id);
		if (c == null) 
		{
			throw new NoSuchElementException("The category with id =" + id + " was not found!");
		}
		return c;
	}
	/**
	 * Method to insert a category to the Category table
	 * @param c category to be inserted
	 * @return the inserted category
	 */
	public Category insertCategory(Category c) 
	{
		return dao.insert(c);
	}
	/**
	 * Deletes a category from the table
	 * @param c category to be deleted
	 * @return the deleted category
	 */
	public Category deleteCategory(Category c)
	{
			return dao.delete(c);
	}
}