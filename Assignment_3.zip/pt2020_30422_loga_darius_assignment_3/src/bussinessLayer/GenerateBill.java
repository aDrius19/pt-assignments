package bussinessLayer;

import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;

/**Class for generating bills for orders
 * @author Loga Darius
 *
 */
public class GenerateBill
{
	
	public static void generateBill(int orderId, ArrayList<String> lines) throws DocumentException, IOException
	{
		Document pdfDoc = new Document(PageSize.A4);
		Path file = Paths.get("bill_for_order" + orderId + ".txt");
		PdfWriter.getInstance(pdfDoc, new FileOutputStream("src/output/txt.pdf")) //for converting a text file to pdf
		.setPdfVersion(PdfWriter.PDF_VERSION_1_7);
		pdfDoc.open();
		Font myfont = new Font();
		myfont.setStyle(Font.NORMAL);
		myfont.setSize(11);
		pdfDoc.add(new Paragraph("\n"));
		BufferedReader br = new BufferedReader(new FileReader(""));
		String strLine;
		while ((strLine = br.readLine()) != null) {
		    Paragraph para = new Paragraph(strLine + "\n", myfont);
		    para.setAlignment(Element.ALIGN_JUSTIFIED);
		    pdfDoc.add(para);
		}   
		pdfDoc.close();
		br.close();
		
		try {
			Files.write(file, lines);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}
	
}
