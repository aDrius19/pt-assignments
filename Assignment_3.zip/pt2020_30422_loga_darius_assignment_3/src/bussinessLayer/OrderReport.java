package bussinessLayer;

import java.io.IOException;
import java.util.ArrayList;
import java.util.NoSuchElementException;

import com.itextpdf.text.DocumentException;

import dao.*;
import model.Client;
import model.Order;
import model.Product;

/**Bussiness Logic class for Order
 * @author Loga Darius
 *
 */
public class OrderReport 
{
	
	private OrderDAO dao;
	private ProductReport productBill;
	/**
	 * Constructor
	 */
	public OrderReport() 
	{
		dao = new OrderDAO();
		productBill = new ProductReport();
	}
	/**
	 * Method to find an order by its id
	 * @param id
	 * @return the order found
	 */
	public Order findOrderById(int id) 
	{
		Order c = dao.findById(id);
		if (c == null) 
		{
			throw new NoSuchElementException("The order with id = " + id + " was not found!");
		}
		return c;
	}
	/**
	 * Method to insert a new order
	 * @param c
	 * @return id of the successfully inserted order
	 * @throws DocumentException 
	 * @throws IOException 
	 */
	public int insertOrder(Order c) throws DocumentException, IOException 
	{
		Product p = productBill.findProductById(c.getIdProduct());
		int id;
		if (p.getStock() >= c.getNbItems()) 
		{ //if the product of the order is in stock
			id = AbstractDAO.insertedId;
			//decrement the product's stock
			productBill.updateProduct(new Product(p.getId(), p.getName(), p.getPrice(), p.getCatId(), p.getStock() - c.getNbItems()));

			ClientReport clBll = new ClientReport();
			Client cl = clBll.findClientById(c.getIdClient());

			//generate a bill if the order can be added
			ArrayList<String> billLines = new ArrayList<String>();
			billLines.add("Order #" + id);
			billLines.add("");
			billLines.add("Customer #" + c.getIdClient() + " with");
			billLines.add("");
			billLines.add("name : " + cl.getName() + ",");
			billLines.add("address : " + cl.getAddress() + ",");
			billLines.add("");
			billLines.add("has ordered " + c.getNbItems() + " products " + p.getName() + "each having the price of " + p.getPrice() + " RON. ");
			billLines.add("");
			billLines.add("Total price of the order: " + c.getNbItems() * p.getPrice() + " RON ");
			billLines.add("");
			GenerateBill.generateBill(id, billLines);
		} else {
			throw new IllegalArgumentException("The order cannot be made because product " + p.getId() + " is under the stock!");
		}
		return id;
	}
}