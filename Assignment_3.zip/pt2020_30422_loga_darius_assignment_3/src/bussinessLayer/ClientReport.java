package bussinessLayer;

import java.util.NoSuchElementException;
import dao.ClientDAO;
import model.Client;

/**Bussiness Logic class for Client
 * @author Loga Darius
 *
 */
public class ClientReport 
{

	private ClientDAO dao;
	/**
	 * Constructor
	 */
	public ClientReport() 
	{
		dao = new ClientDAO();
	}
	/**
	 * Method to find a client by its id, throw an exection if not found
	 * @param id
	 * @return the client found
	 */
	public Client findClientById(int id) 
	{
		Client c = dao.findById(id);
		if (c == null) 
		{
			throw new NoSuchElementException("The client with id = " + id + " was not found!");
		}
		return c;
	}
	/**
	 * Method to insert a client to the Client table
	 * @param c Client to be inserted
	 * @return the inserted Client
	 */
	public Client insertClient(Client c) 
	{
		return dao.insert(c);
	}
	/**
	 * Method to delete a client 
	 * @param c client to be deleted
	 * @return the deleted client
	 */
	public Client deleteClient(Client c)
	{
			return dao.delete(c);
	}
}
