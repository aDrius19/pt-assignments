package dao;

import java.beans.IntrospectionException;
import java.beans.PropertyDescriptor;
import java.lang.reflect.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import dataAccessLayer.dbConnection;

/**
 * Abstract generic class to implement CRUD operations
 * @author Loga Darius
 *
 * @param <T> T can represent any class from the model package: Client, Product, Category or Order
 */
public class AbstractDAO<T> 
{
	public final Class<T> type;
	public static int insertedId = -1;
	
	@SuppressWarnings("unchecked")
	public AbstractDAO()
	{
		this.type = (Class<T>) ((ParameterizedType)getClass().getGenericSuperclass()).getActualTypeArguments()[0];
	}
	/**
	 * Method to find all objects from a table
	 * @return an ArrayList of objects of type T
	 */
	public List<T> findAll() 
	{
		List<T> elements = new ArrayList<T>();
		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		String query = SQLStatements.createSelectAllQuery(type);
		try {
			connection = dbConnection.getConnection();
			statement = connection.prepareStatement(query);
			resultSet = statement.executeQuery();
			elements = createObjects(resultSet);	
		} catch (SQLException e) {
			System.out.println("Error for finding objects!");
		} 
		
		dbConnection.close(resultSet);
		dbConnection.close(statement);
		dbConnection.close(connection);
		
		return elements;
	}
	/**
	 * Method to find an object T by its id
	 * @param id
	 * @return the object T found
	 */
	public T findById(int id) 
	{
		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		String query = SQLStatements.createSelectQuery(type, "id");
		try {
			connection = dbConnection.getConnection();
			statement = connection.prepareStatement(query);
			statement.setInt(1, id);
			resultSet = statement.executeQuery();
			List<T> objects = createObjects(resultSet);
			if(objects.size() > 0)
				return objects.get(0);
			
		} catch (SQLException e) {
			System.out.println("Error for finding objects by Id!");
		} 
		
		dbConnection.close(resultSet);
		dbConnection.close(statement);
		dbConnection.close(connection);
		
		return null;
	}
	/**
	 * Method used in createObjects method to avoid errors. Autoboxes the primitive type of a value to its wrapper class
	 * @param value value to be autoboxed
	 * @param field the field where the value is found
	 * @return the autoboxed object
	 */
	private static Object autoboxValue(Object value, Field field)
	{
		if(!(value instanceof String))
		{
			if(field.getName().contentEquals("price"))
				value = Float.valueOf(value.toString());
			else value = Integer.valueOf(value.toString());
		}
		return value;
	}
	/**
	 * Method to create a list of objects of type T from a resultSet
	 * @param resultSet obtained from a table
	 * @return the list
	 */
	private List<T> createObjects(ResultSet resultSet) 
	{
		List<T> list = new ArrayList<T>();
		try {
			while (resultSet.next()) 
			{
				@SuppressWarnings("deprecation")
				T instance = type.newInstance();
				for (Field field : type.getDeclaredFields()) 
				{
					field.setAccessible(true);
					Object value = resultSet.getObject(field.getName());
					value = autoboxValue(value, field);
					PropertyDescriptor propertyDescriptor = new PropertyDescriptor(field.getName(), type);
					Method method = propertyDescriptor.getWriteMethod();
					method.invoke(instance, value);
				}
				list.add(instance);
			}
		} catch (InstantiationException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (SecurityException e) {
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (IntrospectionException e) {
			e.printStackTrace();
		}
		return list;
	}
	/**
	 * Method to insert an object of type T to its corresponding table by using reflection methods
	 * @param t
	 * @return the id of the inserted object
	 */
	public T insert(T t) 
	{
		Connection connection = null;
		PreparedStatement insertStatement = null;
		String insertStatementString = SQLStatements.createInsertStatement(type);
		
		try {
			connection = dbConnection.getConnection();
			insertStatement = connection.prepareStatement(insertStatementString, Statement.RETURN_GENERATED_KEYS);
			Field fields[] = type.getDeclaredFields();
			for (int i = 1; i < fields.length; i++) 
			{
				PropertyDescriptor propertyDescriptor = new PropertyDescriptor(fields[i].getName(), type);
				Method method = propertyDescriptor.getReadMethod();
				insertStatement.setObject(i, method.invoke(t).toString());
			}
			insertStatement.executeUpdate();
			ResultSet rs = insertStatement.getGeneratedKeys();
			if (rs.next()) 
			{
				insertedId = rs.getInt(1);
			}
		} catch (SQLException e) {
			System.out.println("Error inserting an object to the corresponding table!");
		} catch (IntrospectionException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			e.printStackTrace();
		} 
			
		dbConnection.close(insertStatement);
		dbConnection.close(connection);
		
		return t;
	}
	/**
	 * Method to update an object of type T
	 * @param t
	 * @return the updated object
	 */
	public T update(T t) 
	{
		Connection connection = null;
		PreparedStatement updateStatement = null;
		String updateStatementString = SQLStatements.createUpdateStatementSql(type, "id");
		try {
			connection = dbConnection.getConnection();
			updateStatement = connection.prepareStatement(updateStatementString);
			Field fields[] = type.getDeclaredFields();
			for (int i = 1; i < fields.length; i++) 
			{
				PropertyDescriptor propertyDescriptor = new PropertyDescriptor(fields[i].getName(), type);
				Method method = propertyDescriptor.getReadMethod();
				updateStatement.setObject(i, method.invoke(t).toString());
			}
		    PropertyDescriptor propertyDescriptor = new PropertyDescriptor(fields[0].getName(), type);
			Method method = propertyDescriptor.getReadMethod();
			updateStatement.setObject(fields.length, method.invoke(t).toString());
			updateStatement.executeUpdate();
		} catch (SQLException e) {
			System.out.println("Error updating an object to its corresponding table!");
		} catch (IntrospectionException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			e.printStackTrace();
		} 
			
		dbConnection.close(updateStatement);
		dbConnection.close(connection);
		
		return t;
	}
	/**
	 * Method to delete an object of type T
	 * @param t
	 * @return 
	 */
	public T delete(T t)
	{
		Connection connection = null;
		PreparedStatement deleteStatement = null;
		String deleteStatementString = SQLStatements.createDeleteStatementSql(type, "id");
		@SuppressWarnings("unused")
		int deletedId = -1;
		try 
		{
			connection = dbConnection.getConnection();
			deleteStatement = connection.prepareStatement(deleteStatementString, Statement.RETURN_GENERATED_KEYS);
			Field fields[] = type.getDeclaredFields();
			for (int i = 1; i < fields.length; i++) 
			{
				PropertyDescriptor propertyDescriptor = new PropertyDescriptor(fields[i].getName(), type);
				Method method = propertyDescriptor.getReadMethod();
				deleteStatement.setObject(i, method.invoke(t).toString());
			}
			deleteStatement.executeUpdate();
			ResultSet rs = deleteStatement.getGeneratedKeys();
			if (rs.previous()) 
			{
				deletedId = rs.getInt(1);
			}
		} catch (SQLException e) {
			System.out.println("Error inserting an object to the corresponding table!");
		} catch (IntrospectionException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			e.printStackTrace();
		} 
			
		dbConnection.close(deleteStatement);
		dbConnection.close(connection);
		
		return t;
	}
}
