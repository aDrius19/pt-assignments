package dao;

import model.Category;
/**
 * Category Data Access Class
 * @author Loga Darius
 *
 */
public class CategoryDAO extends AbstractDAO<Category>
{

}
