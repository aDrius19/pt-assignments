package dao;

import model.Client;

/**
 * Client Data Access Class
 * @author Loga Darius
 *
 */
public class ClientDAO extends AbstractDAO<Client>
{

}
