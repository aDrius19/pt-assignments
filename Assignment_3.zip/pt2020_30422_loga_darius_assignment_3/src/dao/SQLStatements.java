package dao;

import java.lang.reflect.Field;

/**
 * Class providing methods to generate SQL queries and statements for accessing the database
 * @author Loga Darius
 *
 */
public class SQLStatements 
{
	/**
	 * Method that created a select query with a where clause
	 * @param type class to generate the query using reflection
	 * @param field the field's name to be added to the where clause of the query
	 * @return the created SQL query as a String
	 */
	public static String createSelectQuery(Class<?> type, String field) 
	{
		StringBuilder sb = new StringBuilder();
		sb.append("SELECT ");
		sb.append(" * ");
		sb.append(" FROM hw3.");
		sb.append(type.getSimpleName());
		sb.append(" WHERE hw3." + type.getSimpleName() + "." + field + " =?");
		return sb.toString();
	}
	/**
	 * Method that created a select all query
	 * @param type class to generate the query using reflection
	 * @return the created SQL query as a String
	 */
	public static String createSelectAllQuery(Class<?> type)
	{
		StringBuilder sb = new StringBuilder();
		sb.append("SELECT ");
		sb.append(" * ");
		sb.append(" FROM hw3.");
		sb.append(type.getSimpleName());
		return sb.toString();
	}
	/**
	 * Method to create an insert SQL statement
	 * @param c
	 * @return the created SQL query as a String
	 */
	public static String createInsertStatement(Class<?> c)
	{
		StringBuilder fields = new StringBuilder();
		StringBuilder vars = new StringBuilder();
		
		for(Field field : c.getDeclaredFields())
		  {
		      String name = field.getName();
		      if(name.contentEquals("id") == false)
		      {
				if (fields.length() > 1) 
				{
					fields.append(",");
					vars.append(",");
				}

				fields.append(name);
				vars.append("?");
			}
		  }
		  String Sql = "INSERT INTO hw3." + c.getSimpleName() + " (" + fields.toString() + ") VALUES(" + vars.toString() + ")";
		  return Sql; 
	}
	/**
	 * Method to create an update SQL statement with where clause
	 * @param c
	 * @param fieldName update based on finding this field name
	 * @return the created SQL query as a String
	 */
	public static String createUpdateStatementSql(Class<?> c, String fieldName)
	{
		StringBuilder sets = new StringBuilder();
		String where = null;
		for (Field field : c.getDeclaredFields()) 
		{
			String name = field.getName();
			String pair = name + " = ?";
			if (name.equals(fieldName)) 
			{
				where = " WHERE " + pair;
			} else if (!name.contentEquals("id"))
			{
				if (sets.length() > 1) {
					sets.append(", ");
				}
				sets.append(pair);
			}
		}
		if (where == null && !fieldName.contentEquals("id")) 
		{
			String string = "Primary key not found in '" + c.getName() + "'";
			throw new IllegalArgumentException(string);
		}
		String Sql = "UPDATE hw3." + c.getSimpleName() + " SET " + sets.toString() + where;
		return Sql;
	}
	/**
	 * Method to create a delete SQL statement
	 * @param c
	 * @param fieldName
	 * @return the created SQL query as a String
	 */
	public static String createDeleteStatementSql(Class<?> c, String fieldName)
	{
		String where = null;
		for (Field field : c.getDeclaredFields()) 
		{
			String name = field.getName();
			String pair = name + " = ?";
			if (name.equals(fieldName)) 
			{
				where = " WHERE " + pair;
			}
		}
		if (where == null) 
		{
			String string = "Primary key not found in '" + c.getName() + "'";
			throw new IllegalArgumentException(string);
		}
		String Sql = "DELETE FROM hw3." + c.getSimpleName() + where;
		return Sql;
	}
}