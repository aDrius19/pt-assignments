package dao;

import model.Order;

/**
 * Order Data Access Class
 * @author Loga Darius
 *
 */
public class OrderDAO extends AbstractDAO<Order>
{

}
