package dao;

import model.Product;
/**
 * Product Data Access Class
 * @author Loga Darius
 *
 */
public class ProductDAO extends AbstractDAO<Product>
{

}
