package presentation;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import model.Client;
import model.Product;
import bussinessLayer.*;

/**
 * Main class for computing the input from the text file
 * @author Loga Darius
 */

public class TextInput 
{
	public static void main(String args[]) throws FileNotFoundException, IOException 
	{
		try (BufferedReader br = new BufferedReader(new FileReader("File1.txt")))
		{
		    String line;
		    while ((line = br.readLine()) != null) 
		    {
		      if(line.equals("Insert client") == true) 
		      {
		    	  String[]buf = line.split(":");
		    	  String[]buff = buf[1].split(",");
		    	  Client c = new Client(buff[0], buff[1]);
		    	  //insertClient(c); the inserted client but i don't know why it won't work
		      }
		      if(line.equals("Insert product") == true) 
		      {	
		    	  String[]buf = line.split(":");
		    	  String[]buff = buf[1].split(",");
		    	  Client c = new Client(buff[0], buff[1]);
		    	  //insertProduct(c); the inserted product but i don't know why it won't work
		    	  
		      }
		      if(line.equals("Delete client") == true)
		      {	
		    	  String[]buf = line.split(":");
		    	  String[]buff = buf[1].split(",");
		    	  Client c = new Client(buff[0], buff[1]);
		    	  //deleteProduct(c); the deleted client but i don't know why it won't work
		    	  
		      }
		      if(line.equals("Delete product") == true)
		      {	
		    	  String[]buf = line.split(":");
		    	  String[]buff = buf[1].split(",");
		    	  Client c = new Client(buff[0], buff[1]);
		    	  //deleteClient(c); the inserted client but i don't know why it won't work
		    	  
		      }
		      if(line.equals("Report product") == true)
		      {	
		    	  
		    	 // List<Product> prod = new ArrayList<Product>();
		    	 // prod = findAll();
		    	  
		      }
		      if(line.equals("Report client") == true)
		      {	
		    	// List<Client> cl = new ArrayList<Client>();
		    	// cl = findAll();
		    	  
		      }
		      if(line.equals("Report order") == true)
		      {	
		    	// List<Order> ord = new ArrayList<Order>();
			    // cl = findAll();
		      }
		    }
		}
	}
	
}

